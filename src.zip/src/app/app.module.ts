import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { AppChallenges } from './challenges.component';
import { AppTimeline } from './timeline.component';
import { AppNearby } from './nearby.component';
import { AppDashboard } from './dashboard.component';
import { PageNotFoundComponent } from  './NotFound.component'
import { RouterModule, Routes } from '@angular/router';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
/*import { FormsModule } from '@angular/forms';
 import { Output } from '@angular/forms';
import { Subject } from "rxjs/Subject";
import "rxjs/add/operator/debounceTime";
import "rxjs/add/operator/distinctUntilChanged"; */
/* import { AppFilter } from './pipes';
import { PipeTransform, Pipe } from '@angular/core'; */

const appRoutes: Routes = [
   { path: 'Challenges', component: AppChallenges },
   { path: 'Timeline', component: AppTimeline },
   { path: 'Nearby', component: AppNearby },
   { path: 'Dashboard', component: AppDashboard },
   { path: '**', component: PageNotFoundComponent }
];

@NgModule ({
   imports: [ BrowserModule,Ng2SearchPipeModule,RouterModule.forRoot(appRoutes)],
   declarations: [AppComponent,AppChallenges,AppTimeline,AppNearby,AppDashboard,PageNotFoundComponent],
   bootstrap: [ AppComponent ]
})
export class AppModule {

	}
