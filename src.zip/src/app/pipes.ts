//our root app component
import {Component, NgModule, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {ReactiveFormsModule, FormsModule, FormControl} from '@angular/forms';
import {Observable, Observer} from 'rxjs/Rx';
import { PipeTransform, Pipe } from '@angular/core';

export interface MyReactiveInputEvent {
  term: string;
  observer: Observer<any>;
}

@Component({
  selector: 'my-reactive-input',
  template: `
    <input [formControl]="searchControl">
    <ul>
      <li *ngFor="let item of items">
        {{item.name}}
      </li>
    </ul>
  `,
})
export class MyReactiveInput implements OnInit {
  searchControl: FormControl = new FormControl();
  @Input() items: any[]
  @Output() onUpdate: EventEmitter<MyReactiveInputEvent> = new EventEmitter()

  ngOnInit() {
    this.searchControl.valueChanges
    .debounceTime(500)
    .distinctUntilChanged()
    .switchMap((term: string) => {
      if (this.onUpdate.observers.length === 0) {
        return Observable.empty()
      }

      this.items = []

      return Observable.create((observer: Observer<any>) => {
        this.onUpdate.emit({term: term, observer: observer})
      })
    })
    .subscribe((item: any) => {
      this.items.push(item)
    })
  }
}

const list: ListItem[] = [
  {name: 'foo'},
  {name: 'bar'},
  {name: 'bar2'},
  {name: '2bar'},
  {name: 'test'}
]

export interface ListItem {
  name: string;
}

@Component({
  selector: 'my-app',
  template: `
    <my-reactive-input [items]="myList" (onUpdate)="search($event)"></my-reactive-input>
  `,
})
export class App {
  myList: ListItem[] = list
   
  search(event: MyReactiveInputEvent) {
    let items = this.myList.filter((e: ListItem) => {
      return new RegExp(event.term, 'gi').test(e.name)
    })
    
    Observable.from(items)
    .subscribe(event.observer)
  }
}

@NgModule({
  imports: [ BrowserModule, FormsModule, ReactiveFormsModule ],
  declarations: [ App, MyReactiveInput ],
  bootstrap: [ App ]
})
export class AppFilter {}