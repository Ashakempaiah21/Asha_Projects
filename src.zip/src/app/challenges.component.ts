import { Component } from '@angular/core';

@Component({
  selector: 'challenges',
  template: `<div class="container-fluid">
				<h1>Challenges</h1>
				<div class="content">
					<div class="decription">
						<figure>
							<img src="../assets/images/card-02.png">						
						</figure>
						<div class="img-details">
							<h2>500 Calories Run</h2>
							<ul class="flex">
								<li>Intermediat</li>
								<li>500 Calories</li>
								<li>500 Points</li>
							</ul>
						</div>
					</div>
					<div class="decription">
						<figure>
							<img src="../assets/images/card-01.png">
						</figure>
					</div>
					<div class="decription">
						<figure>
							<img src="../assets/images/card-02.png">
						</figure>
					</div>
				</div>
			</div>`,
  styleUrls: ['./app.component.css']
})
export class AppChallenges {
 
}
