import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<div class="container-fluid">
				<h1>Dashboard</h1>
				<div class="content">
					<div class="decription">
						<figure>
							<img src="../assets/images/card-02.png">
						</figure>
					</div>
					<div class="decription">
						<figure>
							<img src="../assets/images/card-01.png">
						</figure>
					</div>
					<div class="decription">
						<figure>
							<img src="../assets/images/card-02.png">
						</figure>
					</div>
				</div>
			</div>`,
  styleUrls: ['./app.component.css']
})
export class AppDashboard {
 
}
