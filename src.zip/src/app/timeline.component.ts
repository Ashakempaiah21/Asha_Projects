import { Component } from '@angular/core';

@Component({
  selector: 'timeline',
  template: `<div class="container-fluid">
				<h1>Timeline</h1>
				<div class="content">
					<div class="decription">
						<figure>
							<img src="../assets/images/card-02.png">
						</figure>
					</div>
				</div>
			</div>`,
  styleUrls: ['./app.component.css']
})
export class AppTimeline {
 
}
