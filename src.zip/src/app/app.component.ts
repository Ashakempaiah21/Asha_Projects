import { Component, Output,Input,EventEmitter,OnChanges,SimpleChange, NgModule, NgZone } from '@angular/core';
import {Router } from '@angular/router';
/* import { Subject } from "rxjs/Subject";
import "rxjs/add/operator/debounceTime";
import "rxjs/add/operator/distinctUntilChanged"; */
/* import {AppFilter} from './pipes';
import { PipeTransform, Pipe } from '@angular/core'; */
/* import {platformBrowserDynamic} from '@angular/platform-browser-dynamic'; */

@Component ({
   selector: 'my-app',
  templateUrl: './app.component.html',
  /* template: `<div>
        <input type="text" [(ngModel)]="term">
        <div *ngFor = "let item of items |filter:term" >
          <p>
            {{item.name}}
          </p>
        </div>
     </div> `, */
   styleUrls: ['./app.component.css']
   
})

export class AppComponent  {
} 



